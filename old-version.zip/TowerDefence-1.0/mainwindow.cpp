#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QTimer>
#include <QMouseEvent>
#include <QMessageBox>
#include <stdio.h>
#include<math.h>
#include <string>
#include"enemy.h"
#include"point.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->_x = this->_y = -1;
    timer0 = new QTimer(this);
    connect(timer0,SIGNAL(timeout()),this,SLOT(moveArmy()));//全局时间槽
    timer0->start(10);//10ms
}

MainWindow::~MainWindow()
{
    delete ui;
    delete timer0;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QBrush brush(QColor(255, 255, 255), Qt::Dense1Pattern);

    if(enemy[0].getLife()==0)gameOver(painter);
    else{//背景图
        painter.drawPixmap(rect(), QPixmap("://image/map.jpg"));
        if(buttonCoverFlag)brush.setColor(Qt::darkGreen);
        else brush.setColor(Qt::darkRed);
        painter.setBrush(brush);
        painter.drawEllipse(280,490,70,70);
        towerpic.load("://image/injection.png");
        painter.drawImage(280,490, towerpic);
        time0++;
        //敌人和塔
        painter.setPen(QPen(Qt::white,4));
        for(int i=0;i<virusnum;i++)if(time0>=50*i+300)this->enemy[i].show(painter,i,time0-300);
        for(int i=0;i<townum;i++){this->tower[i].show(painter);}
        //数据显示
        painter.setPen(QPen(Qt::white,4));
        brush.setColor(Qt::black);
        painter.setBrush(brush);
        if(this->_x>0){painter.drawEllipse(this->_x-5,this->_y-5,10,10);}
        ui->label->setText(QString::number(coins)+" ; "+QString::number(this->_x)+" , "+QString::number(this->_y));
        ui->label_2->setText("  "+QString::number(enemy[0].getLife()));
    }
    for(int i=0;i<15;i++){
        painter.drawLine(70*i,0,70*i,700);
        painter.drawLine(0,70*i,1000,70*i);
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){
    this->_x = event->x();
    this->_y = event->y();
    int mx=floor((double)_x/70)*70,my=floor((double)_y/70)*70;
    //塔升级
    int judge=1,jud=1;
    for(int i=0;i<townum;i++){
        if((int)tower[i].getCoor().getX()==mx&&(int)tower[i].getCoor().getY()==my){
            if(tower[i].getLevel()<3&&coins>=100+tower[i].getLevel()*50){
                tower[i].setLevel(tower[i].getLevel()+1);
                coins-=50+tower[i].getLevel()*50;
            }
            judge=0;
            break;
        }
    }
    //建立新塔
    if(judge){//判断此处是否有塔
        if ((_x<350) && (_x>280) && (_y<560) &&(_y>490)){
            if(coins>=100)buttonCoverFlag = true;
        }else if(buttonCoverFlag == true){
            buttonCoverFlag = false;
            for(int i=0;i<18;i++)if(mx==road[i][0]*70&&my==road[i][1]*70){jud=0;break;}
            if(jud&&my>0&&my<490){//判断是否在进攻路线上
                Point tow;
                tow.setX(mx);tow.setY(my);
                tower[townum++].setCoor(tow);
                coins-=100;
            }
        }
    }
}

void MainWindow::moveArmy()
{//重置新一波敌人
    if(enemy[virusnum-1].getHP()<=0){
        time0=0;
        if(virusnum<20)virusnum++;
        int speed=enemy[0].getSpeed();
        for(int i=0;i<virusnum;i++){
            enemy[i].setHP(100);enemy[i].setPaint(true);
            enemy[i].setSpeed(speed+1);
        }
    }
    //塔发射子弹的判断和设置子弹位置
    Point towercoor,viruscoor,p;
    for(int j=0;j<townum;j++){
        towercoor=tower[j].getCoor();
        if(towercoor.getX()>=0)
        for(int i=0;i<virusnum;i++){
            viruscoor=enemy[i].getCoor();
            if(towercoor.dis(viruscoor)<=tower[j].getRange()&&enemy[i].getHP()>0&&enemy[i].getCoor().getX()>0){
                if(timerID[j]==0)timerID[j]=5;
                timerID[j]++;
                p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)timerID[j]/50);
                p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)timerID[j]/50);
                if(timerID[j]%50==0){
                    enemy[i].setHP(enemy[i].getHP()-tower[j].getAttack());timerID[j]=5;
                    if(enemy[i].getHP()<=0)coins+=50;
                }
                break;
            }else{
                p.setX(-1);
                p.setY(-1);
            }
        }
        tower[j].setPoint(p);
    }
    this->repaint();
}

void MainWindow::gameOver(QPainter &painter) {
    painter.setPen(QPen(Qt::black,4));
    QString message = "Game over";
    QFont font("Courier", 20, QFont::DemiBold);
    QFontMetrics fm(font);
    int textWidth = fm.horizontalAdvance(message);
    ui->label->setText("");
    ui->label_2->setText("");
    ui->label_2->setStyleSheet("");

    painter.setFont(font);
    int h = height();
    int w = width();

    painter.translate(QPoint(w/2, h/2));
    painter.drawText(-textWidth/2, 0, message);
}
