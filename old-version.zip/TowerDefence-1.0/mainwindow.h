#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"point.h"
#include"enemy.h"
#include"tower.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected slots:
    void moveArmy();

protected:
    void paintEvent(QPaintEvent *);
    void mouseReleaseEvent(QMouseEvent *event);
    void gameOver(QPainter &painter);
    //void mousePressEvent(QMouseEvent *event);

private:
    Ui::MainWindow *ui;
    QTimer *timer0;
    int timerID[10]={0};
    int _x, _y;
    bool buttonCoverFlag=0;
    Enemy enemy[20];
    int virusnum=10;
    Tower tower[10];
    int townum=0;
    int time0=0;
    int coins=100;
    QImage towerpic;
    int road[18][2]={1,2,1,3,1,4,1,5,2,5,3,5,4,5,4,4,5,4,6,4,7,4,7,5,8,5,9,5,10,5,10,4,10,3,10,2};
};
#endif // MAINWINDOW_H
