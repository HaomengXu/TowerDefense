#ifndef TOWER_H
#define TOWER_H

#include <QPainter>
#include "point.h"
class Tower{
public:

    Tower(){range=150;attack=50;}
    ~Tower(){}
    //Tower(Toewr &t);
    void show(QPainter & painter);
    int getLevel(){return level;}
    void setLevel(int l){level=l;range+=50;attack+=50;}
    int getRange(){return range;}
    int getAttack(){return attack;}
    Point getCoor(){return coor;}
    void setCoor(Point &c){coor=c;}
    Point getPoint(){return bullet;}
    void setPoint(Point &b){bullet=b;}

private:
    int level=1;
    int range;
    int attack;
    Point coor;
    QImage tower1;
    Point bullet;
    double theta=45;
};

#endif // TOWER_H
