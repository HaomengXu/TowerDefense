#ifndef ENEMY_H
#define ENEMY_H

#include <QPainter>
#include "point.h"
class Enemy{
public:
    Enemy(){HP=100;speed=1;}
    ~Enemy(){}
    //Enemy(Enemy &e);
    void show(QPainter & painter,int n,int time);
    void setSpeed(int s){speed=s;}
    int getSpeed(){return speed;}
    int getHP(){return HP;}
    void setHP(int hp){HP=hp;}
    Point getCoor(){return coor;}
    void setCoor(Point & c){coor=c;}
    int getLife(){return life;}
    void setPaint(bool p){paint=p;}

private:
    int speed;
    int HP;
    Point coor;
    QImage virus1;
    bool paint=1;
    static int life;
};

#endif // ENEMY_H
