#ifndef POINT_H
#define POINT_H

#include <QPainter>
#include<cmath>
class Point{
public :
    Point(int xx = -1, int yy = -1) {
            _x = xx;
            _y = yy;
    }
    Point(Point &p){_x=p.getX();_y=p.getY();}

    double dis(Point &p){//距离
        return sqrt((_x-p.getX())*(_x-p.getX())+(_y-p.getY())*(_y-p.getY()));
    }
    void show(QPainter & painter){painter.drawRect(_x-1,_y-1,3,3);}//子弹1
    double getX(){return _x;}
    double getY(){return _y;}
    void setX(double x){_x=x;}
    void setY(double y){_y=y;}
private:
    double _x;
    double _y;
};

#endif // POINT_H
