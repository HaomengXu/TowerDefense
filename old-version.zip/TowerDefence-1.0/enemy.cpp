#include <QPainter>
#include "enemy.h"
#include"point.h"

int Enemy::life=10;

void Enemy::show(QPainter & painter,int n,int time){
    if(HP<=0){paint=0;coor.setX(-1);coor.setY(-1);}
    QBrush brush(QColor(255, 255, 255), Qt::Dense1Pattern);
    painter.setPen(QPen(Qt::white,4));
    virus1.load("://image/virus1.png");
    //坐标判断
    int d=(time-50*n)*speed,x=70,y=140;
    if(d>=210){
        d-=210;y+=210;
        if(d>=210){
            d-=210;x+=210;
            if(d>=70){
               d-=70;y-=70;
               if(d>=210){
                   d-=210;x+=210;
                   if(d>=70){
                       d-=70;y+=70;
                       if(d>=210){
                           d-=210;x+=210;y-=d;
                           if(d==210){paint=0;if(HP>0)life--;HP=0;coor.setX(-1);coor.setY(-1);}
                       }else x+=d;
                   }else y+=d;
               }else x+=d;
            }else y-=d;
        }else x+=d;
    }else y+=d;
    //绘制敌人
    if(paint&&time>=50*n){
        painter.drawImage(x, y, virus1);
        coor.setX(x);coor.setY(y);
        //绘制血量
        brush.setColor(Qt::darkGreen);
        painter.setBrush(brush);
        painter.drawRect(x,y-10,52,4);
        painter.setPen(QPen(Qt::red,3));
        painter.drawRect(x+1,y-9,1+HP*50/100,2);
    }
}
