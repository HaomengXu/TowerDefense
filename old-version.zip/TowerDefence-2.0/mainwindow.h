#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include"point.h"
#include"enemy.h"
#include"enemy2.h"
#include"tower.h"
#include"tower2.h"
#include"tower3.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected slots:
    void moveArmy();

protected:
    void paintEvent(QPaintEvent *);
    void mouseReleaseEvent(QMouseEvent *event);
    void gameOver(QPainter &painter);
    //void levelUP(Tower &it);
    //void mousePressEvent(QMouseEvent *event);

private:
    Ui::MainWindow *ui;
    QTimer *timer0;
    int timerID2[20]={0};
    int timerID3[20]={0};
    int _x, _y;
    int buttonCover=0;
    Enemy enemy[20];
    Enemy2 enemy2[20];
    int virusnum=10,virusnum2=5;
    QVector<Tower> tower;
    QVector<Tower2> tower2;
    QVector<Tower3> tower3;
    int time0=0;
    int coins=500;
    QImage towerpic;
    int road[18][2]={{1,2},{1,3},{1,4},{1,5},{2,5},{3,5},
                     {4,5},{4,4},{5,4},{6,4},{7,4},{7,5},
                     {8,5},{9,5},{10,5},{10,4},{10,3},{10,2}};
};
#endif // MAINWINDOW_H
