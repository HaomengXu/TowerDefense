#include <QPainter>
#include "tower2.h"
#include <QtCore/qmath.h>
#include<cmath>

void Tower2::show(QPainter & painter){//三个等级图片的加载
    QBrush brush(QColor(255, 255, 255), Qt::Dense1Pattern);
    if(level==1)tower.load("://image/facemask.png");
    else if(level==2)tower.load("://image/facemask2.png");
    else tower.load("://image/facemask3.png");
    //塔的绘制
    painter.drawImage(coor.getX(),coor.getY(), tower);
    //根据塔的等级绘制子弹
    /*if(level==1)painter.setPen(QPen(Qt::yellow,4));
    else if(level==2)painter.setPen(QPen(Qt::green,4));
    else painter.setPen(QPen(Qt::red,4));*/
    this->bullet.show2(painter);
}
