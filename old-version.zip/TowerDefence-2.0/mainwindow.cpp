#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QTimer>
#include <QMouseEvent>
#include <QMessageBox>
#include <stdio.h>
#include<math.h>
#include <string>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->_x = this->_y = -1;
    timer0 = new QTimer(this);
    connect(timer0,SIGNAL(timeout()),this,SLOT(moveArmy()));//全局时间槽
    timer0->start(10);//10ms
}

MainWindow::~MainWindow()
{
    delete ui;
    delete timer0;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QBrush brush(QColor(255, 255, 255), Qt::Dense1Pattern);

    if(enemy[0].getLife()==0)gameOver(painter);
    else{//背景图
        painter.drawPixmap(rect(), QPixmap("://image/map.jpg"));
        if(buttonCover==1)brush.setColor(Qt::darkGreen);//第一种塔
        else brush.setColor(Qt::darkRed);
        painter.setBrush(brush);
        painter.drawEllipse(280,490,70,70);
        towerpic.load("://image/injection.png");
        painter.drawImage(280,490, towerpic);
        if(buttonCover==2)brush.setColor(Qt::darkGreen);//第二种塔
        else brush.setColor(Qt::darkRed);
        painter.setBrush(brush);
        painter.drawEllipse(420,490,70,70);
        towerpic.load("://image/facemask.png");
        painter.drawImage(420,490, towerpic);
        if(buttonCover==3)brush.setColor(Qt::darkGreen);//第三种塔
        else brush.setColor(Qt::darkRed);
        painter.setBrush(brush);
        painter.drawEllipse(560,490,70,70);
        towerpic.load("://image/doctor.png");
        painter.drawImage(560,490, towerpic);
        time0++;
        //敌人和塔
        painter.setPen(QPen(Qt::white,4));
        for(int i=0;i<virusnum;i++)if(time0>=50*i+300)this->enemy[i].show(painter,i,time0-300);
        for(int i=0;i<virusnum2;i++)if(time0>=50*(i+virusnum)+300)this->enemy2[i].show(painter,i,time0-300-50*virusnum);
        for(auto it=tower.begin();it!=tower.end();++it){it->show(painter);}
        for(auto it=tower2.begin();it!=tower2.end();++it){it->show(painter);}
        for(auto it=tower3.begin();it!=tower3.end();++it){it->show(painter);}
        //数据显示
        painter.setPen(QPen(Qt::white,4));
        brush.setColor(Qt::black);
        painter.setBrush(brush);
        if(this->_x>0){painter.drawEllipse(this->_x-5,this->_y-5,10,10);}
        ui->label->setText(QString::number(coins));
        //+" ; "+QString::number(this->_x)+" , "+QString::number(this->_y)
        ui->label_2->setText("  "+QString::number(enemy[0].getLife()));
    }
    /*for(int i=0;i<15;i++){
        painter.drawLine(70*i,0,70*i,700);
        painter.drawLine(0,70*i,1000,70*i);
    }*/
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){
    this->_x = event->x();
    this->_y = event->y();
    int mx=floor((double)_x/70)*70,my=floor((double)_y/70)*70;
    //塔升级
    int judge=1,jud=1;
    for(auto it=tower.begin();it!=tower.end();++it){
        if((int)it->getCoor().getX()==mx&&(int)it->getCoor().getY()==my){
            if(it->getLevel()<3&&coins>=it->getMoney()){
                coins-=it->getMoney();
                it->setLevel(it->getLevel()+1);
            }
            judge=0;break;
        }
    }
    if(judge)for(auto it=tower2.begin();it!=tower2.end();++it){
        if((int)it->getCoor().getX()==mx&&(int)it->getCoor().getY()==my){
            if(it->getLevel()<3&&coins>=it->getMoney()){
                coins-=it->getMoney();
                it->setLevel(it->getLevel()+1);
            }
            judge=0;break;
        }
    }
    if(judge)for(auto it=tower3.begin();it!=tower3.end();++it){
        if((int)it->getCoor().getX()==mx&&(int)it->getCoor().getY()==my){
            if(it->getLevel()<3&&coins>=it->getMoney()){
                coins-=it->getMoney();
                it->setLevel(it->getLevel()+1);
            }
            judge=0;break;
        }
    }

    //建立新塔
    if(judge){//judge判断此处是否有塔
        Tower t;Tower2 t2;Tower3 t3;
        if ((_x<350) && (_x>280) && (_y<560) &&(_y>490)){if(coins>=t.getMoney())buttonCover = 1;}
        else if ((_x<490) && (_x>420) && (_y<560) &&(_y>490)){if(coins>=t2.getMoney())buttonCover = 2;}
        else if ((_x<630) && (_x>560) && (_y<560) &&(_y>490)){if(coins>=t3.getMoney())buttonCover = 3;}
        else if(buttonCover){
            for(int i=0;i<18;i++)if(mx==road[i][0]*70&&my==road[i][1]*70){jud=0;break;}
            if(jud&&my>0&&my<490){//判断是否在进攻路线上
                Point p_tow(mx,my);
                if(buttonCover==1){
                    t.setCoor(p_tow);
                    coins-=t.getMoney();
                    t.setLevel(1);
                    tower.push_back(t);
                }else if(buttonCover==2){
                    t2.setCoor(p_tow);
                    coins-=t2.getMoney();
                    t2.setLevel(1);
                    tower2.push_back(t2);
                }
                else{
                    t3.setCoor(p_tow);
                    coins-=t3.getMoney();
                    t3.setLevel(1);
                    tower3.push_back(t3);
                }
            }
            buttonCover = 0;
        }
    }
}

void MainWindow::moveArmy()
{//重置新一波敌人
    int alldie=1;
    for(int i=0;i<virusnum;i++)if(enemy[i].getHP()>0){alldie=0;break;}
    for(int i=0;i<virusnum2;i++)if(enemy2[i].getHP()>0){alldie=0;break;}
    if(alldie){
        time0=0;
        if(virusnum<20)virusnum++;
        if(virusnum2<20)virusnum2+=2;
        int speed=enemy[0].getSpeed();
        if(speed>3)speed--;
        for(int i=0;i<virusnum;i++){
            enemy[i].setHP(100);
            enemy[i].setSpeed(speed+1);
        }
        speed=enemy2[0].getSpeed();
        if(speed>4)speed--;
        for(int i=0;i<virusnum2;i++){
            enemy2[i].setHP(150);
            enemy2[i].setSpeed(speed+1);
        }
    }
    //塔发射子弹的判断和设置子弹位置
    Point towercoor,viruscoor,p;
    for(auto it=tower.begin();it!=tower.end();++it){
        towercoor=it->getCoor();
        bool attacked=0;
        for(int i=0;i<virusnum2;i++){
            viruscoor=enemy2[i].getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&enemy2[i].getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    enemy2[i].setHP(enemy2[i].getHP()-it->getAttack());it->setTimer(5);
                    if(enemy2[i].getHP()<=0)coins+=enemy2[i].getMoney();
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);}
        }
        if(!attacked)for(int i=0;i<virusnum;i++){
            viruscoor=enemy[i].getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&enemy[i].getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    enemy[i].setHP(enemy[i].getHP()-it->getAttack());it->setTimer(5);
                    if(enemy[i].getHP()<=0)coins+=enemy[i].getMoney();
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);}
        }
        it->setPoint(p);
    }
    p.setX(-1);p.setY(-1);
    for(auto it=tower2.begin();it!=tower2.end();++it){
        towercoor=it->getCoor();
        bool attacked=0;
        for(int i=0;i<virusnum2;i++){
            viruscoor=enemy2[i].getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&enemy2[i].getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    enemy2[i].setSpeed((enemy2[i].getSpeed()+1)/2);
                    enemy2[i].setHP(enemy2[i].getHP()-it->getAttack());it->setTimer(5);
                    if(enemy2[i].getHP()<=0)coins+=enemy2[i].getMoney();
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);}
        }
        if(!attacked)for(int i=0;i<virusnum;i++){
            viruscoor=enemy[i].getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&enemy[i].getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    enemy[i].setSpeed((enemy[i].getSpeed()+1)/2);
                    enemy[i].setHP(enemy[i].getHP()-it->getAttack());it->setTimer(5);
                    if(enemy[i].getHP()<=0)coins+=enemy[i].getMoney();
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);}
        }
        it->setPoint(p);
    }
    p.setX(-1);p.setY(-1);
    for(auto it=tower3.begin();it!=tower3.end();++it){
        bool attackjudge=0;
        towercoor=it->getCoor();
        for(int i=0;i<virusnum2;i++){
            viruscoor=enemy2[i].getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&enemy2[i].getHP()>0&&viruscoor.getX()>0){
                attackjudge=1;
                if(it->getTimer()>=it->getInter()+30){
                    enemy2[i].setHP(enemy2[i].getHP()-it->getAttack());
                    if(enemy2[i].getHP()<=0)coins+=enemy2[i].getMoney();
                }
            }
        }
        for(int i=0;i<virusnum;i++){
            viruscoor=enemy[i].getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&enemy[i].getHP()>0&&viruscoor.getX()>0){
                attackjudge=1;
                if(it->getTimer()>=it->getInter()+30){
                    enemy[i].setHP(enemy[i].getHP()-it->getAttack());
                    if(enemy[i].getHP()<=0)coins+=enemy[i].getMoney();
                }
            }
        }
        if(attackjudge){
            if(it->getTimer()>=it->getInter()){
                if(it->getTimer()<it->getInter()+20)p.setX(35+towercoor.getX()+it->getRange()*(double)(it->getTimer()-it->getInter())/20);
                else p.setX(35+towercoor.getX()+it->getRange());
                p.setY(35+towercoor.getY());
            }
            it->setTimer(it->getTimer()+1);
        }else{p.setX(-1);p.setY(-1);}
        if(it->getTimer()>it->getInter()+30)it->setTimer(30);
        it->setPoint(p);
    }
    this->repaint();
}

void MainWindow::gameOver(QPainter &painter) {
    painter.setPen(QPen(Qt::black,4));
    QString message = "Game over";
    QFont font("Courier", 20, QFont::DemiBold);
    QFontMetrics fm(font);
    int textWidth = fm.horizontalAdvance(message);
    ui->label->setText("");
    ui->label_2->setText("");
    ui->label_2->setStyleSheet("");

    painter.setFont(font);
    int h = height();
    int w = width();

    painter.translate(QPoint(w/2, h/2));
    painter.drawText(-textWidth/2, 0, message);
}
