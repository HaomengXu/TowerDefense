#ifndef TOWER2_H
#define TOWER2_H

#include <QPainter>
#include "point.h"
#include "tower.h"
class Tower2:public Tower{
public:
    Tower2(){range=80-80;attack=40-30;money=120;interval=40;}
    ~Tower2(){}
    Tower2(const Tower2& t){
        level=t.level;
        money=t.money;
        range=t.range;
        attack=t.attack;
        coor=t.coor;
    }

    void setLevel(int l){level=l;range+=80;attack+=30;money+=100;interval-=15;}
    void show(QPainter & painter);
};

#endif // TOWER2_H
