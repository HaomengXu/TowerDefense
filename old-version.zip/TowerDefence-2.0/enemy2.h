#ifndef ENEMY2_H
#define ENEMY2_H

#include <QPainter>
#include "point.h"
#include "enemy.h"
class Enemy2:public Enemy{
public:
    Enemy2(){fullHP=HP=200;speed=2;money=30;virus.load("://image/virus2.png");}
    ~Enemy2(){}
    /*Enemy2(Enemy2 &e){
        HP=e.getHP();
        coor=e.getCoor();
    }*/
};

#endif // ENEMY2_H
