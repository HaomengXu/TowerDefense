#include <QPainter>
#include "tower3.h"
#include <QtCore/qmath.h>
#include<cmath>

void Tower3::show(QPainter & painter){//三个等级图片的加载
    QBrush brush(QColor(255, 255, 255), Qt::Dense5Pattern);
    if(level==1)tower.load("://image/doctor.png");
    //else if(level==2)tower.load("://image/doctor.png");
    //else tower.load("://image/doctor.png");
    //塔的绘制
    painter.drawImage(coor.getX(),coor.getY(), tower);
    //根据塔的等级绘制子弹
    if(level==1){brush.setColor(Qt::yellow);painter.setPen(QPen(Qt::yellow,4));}
    else if(level==2){brush.setColor(Qt::green);painter.setPen(QPen(Qt::green,4));}
    else {brush.setColor(Qt::red);painter.setPen(QPen(Qt::red,4));}
    painter.setBrush(brush);
    double d=coor.dis(bullet);
    if(bullet.getX()>0)this->bullet.show3(painter,coor,d);
}
