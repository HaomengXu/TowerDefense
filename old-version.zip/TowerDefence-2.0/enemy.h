#ifndef ENEMY_H
#define ENEMY_H

#include <QPainter>
#include "point.h"
class Enemy{
public:
    Enemy(){fullHP=HP=100;speed=1;virus.load("://image/virus1.png");}
    ~Enemy(){}
    /*Enemy(Enemy &e){
        HP=e.getHP();
        coor=e.getCoor();
    }*/
    void show(QPainter & painter,int n,int time);
    void setSpeed(int s){speed=s;}
    int getSpeed(){return speed;}
    int getHP(){return HP;}
    int getMoney(){return money;}
    void setHP(int hp){HP=hp;}
    Point getCoor(){return coor;}
    void setCoor(Point & c){coor=c;}
    int getLife(){return life;}

protected:
    int speed;
    int HP;
    int fullHP;
    int money=20;
    Point coor;
    QImage virus;
    static int life;
};

#endif // ENEMY_H
