#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QTimer>
#include <QMouseEvent>
#include <QMessageBox>
#include <stdio.h>
#include<math.h>
#include <string>
#include <iostream>
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->_x = this->_y = -1;
    timer0 = new QTimer(this);
    connect(timer0,SIGNAL(timeout()),this,SLOT(moveArmy()));//全局时间槽
    timer0->start(10);//10ms
}

MainWindow::~MainWindow()
{
    delete ui;
    delete timer0;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QBrush brush(QColor(255, 255, 255), Qt::Dense2Pattern);

    if(enemy[0].getLife()==0)gameOver(painter);
    else{
        painter.drawPixmap(rect(), QPixmap("://image/map.jpg"));
        time0++;
        //敌人和塔
        painter.setPen(QPen(Qt::white,4));
        for(auto it=enemy.begin();it!=enemy.end();){
            if(it->getHP()<=0){enemy.erase(it);virusnum--;time0-=50;}//得逞的敌人
            else {it->show(painter);it++;}
        }
        for(auto it=enemy2.begin();it!=enemy2.end();){
            if(it->getHP()<=0){enemy2.erase(it);virusnum2--;time0-=50;}
            else {it->show(painter);it++;}
        }
        if(time0%30<15)towerpic.load("://image/LevelUp.png");
        else towerpic.load("://image/LevelUp2.png");
        for(auto it=tower2.begin();it!=tower2.end();++it){
            it->show(painter);
            if(coins>=it->getMoney()&&it->getLevel()<3)
                painter.drawImage(it->getCoor().getX()+20,it->getCoor().getY()-15, towerpic);
        }
        for(auto it=tower3.begin();it!=tower3.end();++it){
            it->show(painter);
            if(coins>=it->getMoney()&&it->getLevel()<3)
                painter.drawImage(it->getCoor().getX()+20,it->getCoor().getY()-15, towerpic);
        }
        for(auto it=tower.begin();it!=tower.end();++it){
            it->show(painter);
            if(coins>=it->getMoney()&&it->getLevel()<3)
                painter.drawImage(it->getCoor().getX()+20,it->getCoor().getY()-15, towerpic);
        }
        //选择建立新塔
        if(_x>=0){
            painter.setPen(QPen(Qt::white,4));
            brush.setColor(Qt::lightGray);
            painter.setBrush(brush);
            painter.drawRoundedRect(_x+5,_y+5,60,60,20,20);
            painter.drawLine(_x+35,_y+30,_x+35,_y+40);
            painter.drawLine(_x+30,_y+35,_x+40,_y+35);
            if(coins>=100)brush.setColor(Qt::darkGreen);//第一种塔
            else brush.setColor(Qt::darkRed);
            painter.setBrush(brush);
            if(_x>0&&_x<770)painter.drawRoundedRect(_x-70+3,_y+70+3,70-6,70-6,15,15);
            else if(_x==0)painter.drawRoundedRect(_x+3,_y+70+3,70-6,70-6,15,15);
            else if(_x==770)painter.drawRoundedRect(_x-140+3,_y+70+3,70-6,70-6,15,15);
            towerpic.load("://image/injection.png");
            if(_x>0&&_x<770)painter.drawImage(_x-70,_y+70, towerpic);
            else if(_x==0)painter.drawImage(_x,_y+70, towerpic);
            else if(_x==770)painter.drawImage(_x-140,_y+70, towerpic);
            if(coins>=120)brush.setColor(Qt::darkGreen);//第二种塔
            else brush.setColor(Qt::darkRed);
            painter.setBrush(brush);
            if(_x>0&&_x<770)painter.drawRoundedRect(_x+3,_y+70+3,70-6,70-6,15,15);
            else if(_x==0)painter.drawRoundedRect(_x+70+3,_y+70+3,70-6,70-6,15,15);
            else if(_x==770)painter.drawRoundedRect(_x-70+3,_y+70+3,70-6,70-6,15,15);
            towerpic.load("://image/facemask.png");
            if(_x>0&&_x<770)painter.drawImage(_x,_y+70, towerpic);
            else if(_x==0)painter.drawImage(_x+70,_y+70, towerpic);
            else if(_x==770)painter.drawImage(_x-70,_y+70, towerpic);
            if(coins>=150)brush.setColor(Qt::darkGreen);//第三种塔
            else brush.setColor(Qt::darkRed);
            painter.setBrush(brush);
            if(_x>0&&_x<770)painter.drawRoundedRect(_x+70+3,_y+70+3,70-6,70-6,15,15);
            else if(_x==0)painter.drawRoundedRect(_x+140+3,_y+70+3,70-6,70-6,15,15);
            else if(_x==770)painter.drawRoundedRect(_x+3,_y+70+3,70-6,70-6,15,15);
            towerpic.load("://image/doctor.png");
            if(_x>0&&_x<770)painter.drawImage(_x+70,_y+70, towerpic);
            else if(_x==0)painter.drawImage(_x+140,_y+70, towerpic);
            else if(_x==770)painter.drawImage(_x,_y+70, towerpic);
        }
        //数据显示
        /*painter.setPen(QPen(Qt::white,4));brush.setColor(Qt::black);painter.setBrush(brush);
        if(this->_x>0){painter.drawEllipse(this->_x-5,this->_y-5,10,10);}*/
        ui->label->setText(QString::number(coins));
        //+" ; "+QString::number(this->_x)+" , "+QString::number(this->_y)
        ui->label_2->setText("  "+QString::number(enemy[0].getLife()));
    }
    //for(int i=0;i<15;i++){painter.drawLine(70*i,0,70*i,700);painter.drawLine(0,70*i,1000,70*i);}
}

void MainWindow::mousePressEvent(QMouseEvent *event){
    int x = event->x(),y = event->y();
    int mx=floor((double)x/70)*70,my=floor((double)y/70)*70;
    //塔升级
    int judge=1,jud=1;
if(buttonCover==0){
    for(auto it=tower.begin();it!=tower.end();++it){
        if((int)it->getCoor().getX()==mx&&(int)it->getCoor().getY()==my){
            if(event->button()==Qt::LeftButton){
                if(it->getLevel()<3&&coins>=it->getMoney()){
                    coins-=it->getMoney();
                    it->setLevel(it->getLevel()+1);
                }
            }else if(event->button()==Qt::RightButton){
                coins+=100*it->getLevel()*0.8;
                tower.erase(it);
            }
            judge=0;break;
        }
    }
    if(judge)for(auto it=tower2.begin();it!=tower2.end();++it){
        if((int)it->getCoor().getX()==mx&&(int)it->getCoor().getY()==my){
            if(event->button()==Qt::LeftButton){
                if(it->getLevel()<3&&coins>=it->getMoney()){
                    coins-=it->getMoney();
                    it->setLevel(it->getLevel()+1);
                }
            }else if(event->button()==Qt::RightButton){
                coins+=120*it->getLevel()*0.8;
                tower2.erase(it);
            }
            judge=0;break;
        }
    }
    if(judge)for(auto it=tower3.begin();it!=tower3.end();++it){
        if((int)it->getCoor().getX()==mx&&(int)it->getCoor().getY()==my){
            if(event->button()==Qt::LeftButton){
                if(it->getLevel()<3&&coins>=it->getMoney()){
                    coins-=it->getMoney();
                    it->setLevel(it->getLevel()+1);
                }
            }else if(event->button()==Qt::RightButton){
                coins+=150*it->getLevel()*0.8;
                tower3.erase(it);
            }
            judge=0;break;
        }
    }
}
    //建立新塔
    if(judge){//judge判断此处是否有塔,jud判断是否在进攻路线上
        if(_x<0){
            for(int i=0;i<18;i++)if(mx==road[i][0]*70&&my==road[i][1]*70){jud=0;break;}
            if(jud&&my>0&&my<490){_x=mx;_y=my;buttonCover=1;}
        }
        else{
            Point p_tow(_x,_y);
            if(_y+70==my){
                if((_x>0&&_x<770&&_x-70==mx)||(_x==0&&_x==mx)||(_x==770&&_x-140==mx)){
                    if(coins>=100){
                        Tower t;
                        t.setCoor(p_tow);
                        coins-=t.getMoney();
                        t.setLevel(1);
                        tower.push_back(t);
                    }
                }else if((_x>0&&_x<770&&_x==mx)||(_x==0&&_x+70==mx)||(_x==770&&_x-70==mx)){
                    if(coins>=120){
                        Tower2 t2;
                        t2.setCoor(p_tow);
                        coins-=t2.getMoney();
                        t2.setLevel(1);
                        tower2.push_back(t2);
                    }
                }
                else if((_x>0&&_x<770&&_x+70==mx)||(_x==0&&_x+140==mx)||(_x==770&&_x==mx)){
                    if(coins>=150){
                        Tower3 t3;
                        t3.setCoor(p_tow);
                        coins-=t3.getMoney();
                        t3.setLevel(1);
                        tower3.push_back(t3);
                    }
                }
            }
            if(_x!=mx||_y!=my){_x=-1;_y=-1;buttonCover=0;}
        }
    }
}

bool comp(Enemy e1,Enemy e2){
    return e1.getTime()>e2.getTime();
}
bool comp2(Enemy2 e1,Enemy2 e2){
    return e1.getTime()>e2.getTime();
}

void MainWindow::moveArmy()
{//新一敌人
    if(enemy.count()<virusnum&&time0>=50*enemy.count()+500){
        Enemy e;
        enemy.push_back(e);
    }
    sort(enemy.begin(),enemy.end(),comp);
    if(enemy2.count()<virusnum2&&time0>=50*enemy2.count()+50*virusnum+500){
        Enemy2 e2;
        enemy2.push_back(e2);
    }
    sort(enemy2.begin(),enemy2.end(),comp2);

    if(!enemy.count()&&!enemy2.count()&&time0>500){
        time0=0;
        //virussum++;virussum2+=2;
        virusnum=virussum;
        virusnum2=virussum2;
    }
    //塔发射子弹的判断和设置子弹位置
    Point towercoor,viruscoor,p;
    for(auto it=tower.begin();it!=tower.end();++it){
        towercoor=it->getCoor();
        bool attacked=0;
        for(auto ta=enemy2.begin();ta!=enemy2.end();++ta){
            viruscoor=ta->getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&ta->getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    ta->setHP(ta->getHP()-it->getAttack());it->setTimer(5);
                    if(ta->getHP()<=0){coins+=ta->getMoney();/*enemy2.erase(ta);virusnum2--;*/}
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);}
        }
        if(!attacked)for(auto ta=enemy.begin();ta!=enemy.end();++ta){
            viruscoor=ta->getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&ta->getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    ta->setHP(ta->getHP()-it->getAttack());it->setTimer(5);
                    if(ta->getHP()<=0){coins+=ta->getMoney();/*enemy.erase(ta);virusnum--;*/}
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);}
        }
        it->setPoint(p);
    }
    p.setX(-1);p.setY(-1);
    for(auto it=tower2.begin();it!=tower2.end();++it){
        towercoor=it->getCoor();
        bool attacked=0;
        for(auto ta=enemy2.begin();ta!=enemy2.end();++ta){
            viruscoor=ta->getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&ta->getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    if(ta->getSpeed()>=1)ta->setSpeed((ta->getSpeed()+1)/(double)(it->getLevel()+2));
                    ta->setHP(ta->getHP()-it->getAttack());it->setTimer(5);
                    if(ta->getHP()<=0){coins+=ta->getMoney();/*enemy2.erase(ta);virusnum2--;*/}
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);
                if(towercoor.dis(viruscoor)<=it->getRange()+1)ta->setSpeed(ta->getNormsp());}
        }
        if(!attacked)for(auto ta=enemy.begin();ta!=enemy.end();++ta){
            viruscoor=ta->getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&ta->getHP()>0&&viruscoor.getX()>0){
                if(it->getTimer()>=it->getInter()){
                    p.setX(35+towercoor.getX()+(viruscoor.getX()-towercoor.getX())*(double)(it->getTimer()-it->getInter())/20);
                    p.setY(35+towercoor.getY()+(viruscoor.getY()-towercoor.getY())*(double)(it->getTimer()-it->getInter())/20);
                }
                if(it->getTimer()>=20+it->getInter()){
                    if(ta->getSpeed()>=1)ta->setSpeed((ta->getSpeed()+1)/(double)(it->getLevel()+2));
                    ta->setHP(ta->getHP()-it->getAttack());it->setTimer(5);
                    if(ta->getHP()<=0){coins+=ta->getMoney();/*enemy.erase(ta);virusnum--;*/}
                }
                it->setTimer(it->getTimer()+1);
                attacked=1;break;
            }else{p.setX(-1);p.setY(-1);
                if(towercoor.dis(viruscoor)<=it->getRange()+1)ta->setSpeed(ta->getNormsp());}
        }
        it->setPoint(p);
    }
    p.setX(-1);p.setY(-1);
    for(auto it=tower3.begin();it!=tower3.end();++it){
        bool attackjudge=0;
        towercoor=it->getCoor();
        for(auto ta=enemy2.begin();ta!=enemy2.end();++ta){
            viruscoor=ta->getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&ta->getHP()>0&&viruscoor.getX()>0){
                attackjudge=1;
                if(it->getTimer()>=it->getInter()+30){
                    ta->setHP(ta->getHP()-it->getAttack());
                    if(ta->getHP()<=0){coins+=ta->getMoney();/*enemy2.erase(ta);virusnum2--;*/}
                    //else ta++;
                }//else ta++;
            }//else ta++;
        }
        for(auto ta=enemy.begin();ta!=enemy.end();++ta){
            viruscoor=ta->getCoor();
            if(towercoor.dis(viruscoor)<=it->getRange()&&ta->getHP()>0&&viruscoor.getX()>0){
                attackjudge=1;
                if(it->getTimer()>=it->getInter()+30){
                    ta->setHP(ta->getHP()-it->getAttack());
                    if(ta->getHP()<=0){coins+=ta->getMoney();/*enemy.erase(ta);virusnum--;*/}
                    //else ta++;
                }//else ta++;
            }//else ta++;
        }
        if(attackjudge){
            if(it->getTimer()>=it->getInter()){
                if(it->getTimer()<it->getInter()+20)
                    p.setX(35+towercoor.getX()+it->getRange()*(double)(it->getTimer()-it->getInter())/20);
                else p.setX(35+towercoor.getX()+it->getRange());
                p.setY(35+towercoor.getY());
            }
            it->setTimer(it->getTimer()+1);
        }else{p.setX(-1);p.setY(-1);}
        if(it->getTimer()>it->getInter()+30)it->setTimer(30);
        it->setPoint(p);
    }
    this->repaint();
}

void MainWindow::gameOver(QPainter &painter) {
    painter.setPen(QPen(Qt::black,4));
    QString message = "Game over";
    QFont font("Courier", 20, QFont::DemiBold);
    QFontMetrics fm(font);
    int textWidth = fm.horizontalAdvance(message);
    ui->label->setText("");
    ui->label_2->setText("");
    ui->label_2->setStyleSheet("");

    painter.setFont(font);
    int h = height();
    int w = width();

    painter.translate(QPoint(w/2, h/2));
    painter.drawText(-textWidth/2, 0, message);
}
