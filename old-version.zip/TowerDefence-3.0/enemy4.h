#ifndef ENEMY4_H
#define ENEMY4_H

#include <QPainter>
#include "point.h"
#include "enemy.h"
class Enemy4:public Enemy{
public:
    Enemy4(){fullHP=HP=2000;normspeed=speed=1;money=100;
             virus.load("://image/virus4.png");light.load("://image/Light.png");}
    ~Enemy4(){/**/}
    Enemy4(const Enemy4 &e){
        timeline=e.timeline;
        fullHP=2000;
        normspeed=1;
        HP=e.HP;
        speed=e.speed;
        coor=e.coor;
        virus=e.virus;
        light=e.light;
    }
    void show(QPainter & painter);
};

#endif // ENEMY4_H
