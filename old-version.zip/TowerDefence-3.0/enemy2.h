#ifndef ENEMY2_H
#define ENEMY2_H

#include <QPainter>
#include "point.h"
#include "enemy.h"
class Enemy2:public Enemy{
public:
    Enemy2(){fullHP=HP=150;normspeed=speed=2;money=30;
             virus.load("://image/virus2.png");light.load("://image/Light.png");}
    ~Enemy2(){/**/}
    Enemy2(const Enemy2 &e){
        timeline=e.timeline;
        fullHP=150;
        normspeed=2;
        HP=e.HP;
        speed=e.speed;
        coor=e.coor;
        virus=e.virus;
        light=e.light;
    }
    void show(QPainter & painter);
};

#endif // ENEMY2_H
