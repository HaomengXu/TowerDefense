#ifndef ENEMY3_H
#define ENEMY3_H

#include <QPainter>
#include "point.h"
#include "enemy.h"
class Enemy3:public Enemy{
public:
    Enemy3(){fullHP=HP=400;normspeed=speed=1;money=40;
             virus.load("://image/virus3.png");light.load("://image/Light.png");}
    ~Enemy3(){/**/}
    Enemy3(const Enemy3 &e){
        timeline=e.timeline;
        fullHP=400;
        normspeed=1;
        HP=e.HP;
        speed=e.speed;
        coor=e.coor;
        virus=e.virus;
        light=e.light;
    }
    //void show(QPainter & painter);
};

#endif // ENEMY3_H
