#ifndef TOWER3_H
#define TOWER3_H

#include <QPainter>
#include "point.h"
#include "tower.h"
class Tower3:public Tower{
public:
    Tower3(){range=100-20;attack=50-30;money=150;timerID=100;interval=100+10;}
    ~Tower3(){}
    Tower3(const Tower3& t){
        level=t.level;
        money=t.money;
        range=t.range;
        attack=t.attack;
        coor=t.coor;
    }

    void setLevel(int l){level=l;range+=20;attack+=30;money+=120;interval-=10;}
    void show(QPainter & painter);
};

#endif // TOWER3_H
