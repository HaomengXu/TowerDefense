#ifndef TOWER_H
#define TOWER_H

#include <QPainter>
#include "point.h"
class Tower{
public:
    Tower(){}
    ~Tower(){}
    Tower(const Tower& t){
        level=t.level;
        money=t.money;
        range=t.range;
        attack=t.attack;
        coor=t.coor;
    }

    void show(QPainter & painter);
    int getLevel(){return level;}
    void setLevel(int l){level=l;range+=80;attack+=20;money+=80;interval-=15;}
    int getTimer(){return timerID;}
    void setTimer(int t){timerID=t;}
    int getMoney(){return money;}
    int getRange(){return range;}
    int getInter(){return interval;}
    int getAttack(){return attack;}
    Point getCoor(){return coor;}
    void setCoor(Point &c){coor=c;}
    Point getPoint(){return bullet;}
    void setPoint(Point &b){bullet=b;}

protected:
    int level=0;
    int money=100;
    int range=150-80;
    int attack=60-20;
    int timerID=5;
    Point coor;
    QImage tower;
    Point bullet;
    int interval=60;
private:
    double theta=45;
};

#endif // TOWER_H
