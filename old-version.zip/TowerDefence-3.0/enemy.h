#ifndef ENEMY_H
#define ENEMY_H

#include <QPainter>
#include "point.h"
//#include <QMessageBox>
class Enemy{
public:
    Enemy():normspeed(1),fullHP(100){HP=fullHP;speed=normspeed;
                                     virus.load("://image/virus1.png");light.load("://image/Light.png");}
    ~Enemy(){/*QMessageBox::information(NULL,"~Enemy","die");*/}
    Enemy(const Enemy &e):normspeed(1),fullHP(100){
        timeline=e.timeline;
        coor=e.coor;
        speed=e.speed;
        HP=e.HP;
        virus=e.virus;
        light=e.light;
    }
    void show(QPainter & painter);
    void setSpeed(double s){speed=s;}
    double getSpeed(){return speed;}
    int getNormsp(){return normspeed;}
    int getHP(){return HP;}
    void setHP(int hp){HP=hp;}
    Point getCoor(){return coor;}
    void setCoor(Point & c){coor=c;}
    int getLife(){return life;}
    int getMoney(){return money;}
    double getTime(){return timeline;}

protected:
    double timeline=0;
    Point coor;
    double speed;
    int normspeed;
    int HP;
    int fullHP;
    int money=20;
    QImage virus,light;
    static int life;
};

#endif // ENEMY_H
