#include <QPainter>
#include "enemy.h"
#include"point.h"

int Enemy::life=10;

void Enemy::show(QPainter & painter){
    QBrush brush(QColor(255, 255, 255), Qt::Dense1Pattern);
    painter.setPen(QPen(Qt::white,4));
    //坐标判断
    int d=timeline,x=70,y=140;
    if(d>=210){
        d-=210;y+=210;
        if(d>=210){
            d-=210;x+=210;
            if(d>=70){
               d-=70;y-=70;
               if(d>=210){
                   d-=210;x+=210;
                   if(d>=70){
                       d-=70;y+=70;
                       if(d>=210){
                           d-=210;x+=210;y-=d;
                           if(d>210){if(HP>0)life--;HP=0;}
                       }else x+=d;
                   }else y+=d;
               }else x+=d;
            }else y-=d;
        }else x+=d;
    }else y+=d;
    //绘制敌人
    if(HP>0){
        painter.drawImage(x, y, virus);
        coor.setX(x);coor.setY(y);
        //绘制血量
        brush.setColor(Qt::darkGreen);
        painter.setBrush(brush);
        painter.drawRect(x,y-10,52,4);
        painter.setPen(QPen(Qt::lightGray,3));
        painter.drawRect(x+1,y-9,50,2);
        painter.setPen(QPen(Qt::red,3));
        painter.drawRect(x+1,y-9,HP*50/fullHP,2);
        if(timeline<=30){
            painter.save();
            painter.translate(105,165);
            painter.rotate(timeline*10);
            painter.setOpacity(1-timeline*0.02);
            painter.drawImage(-40, -40, light);
            painter.restore();
        }
        timeline+=speed;
    }

}
